package GerenciamentoTarefa.com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerenciamentoTarefaApplication {
    public static void main(String[] args) {
        SpringApplication.run(GerenciamentoTarefaApplication.class, args);
    }
}
